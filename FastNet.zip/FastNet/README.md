<!DOCTYPE html>
<h2 align="center">
🚀 Installation Script By FastNet 🚀<br>
</h2 align="center">
</b>

<pre><code>
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/lianpujisatria/FastNet/main/setup.sh && chmod +x setup.sh && screen -S install ./setup.sh

</code></pre>

(Jika dalam proses instalasi, terjadi diskoneksi pada terminal. Jangan masukkan kembali perintah instalasi. Silahkan masukkan perintah screen -r install untuk melihat proses yang telah berjalan.) 

</b>
♦️ buat akses root (KHUSUS SERVER AMAZON)

<pre><code>sudo su

</code></pre>

<pre><code>cd

</code></pre>

<pre><code>wget https://raw.githubusercontent.com/lianpujisatria/FastNet/main/vpsroot.sh && chmod +x vpsroot.sh && ./vpsroot.sh

</code></pre>


<h2 align="center">
<hr>
🚀 SEBELUM INSTALL SCRIPT HARAP DAFTARKAN DULU IP VPS KAMU 🚀
🚀 KIRIM IP VPS KE SAYA LEWAT Link DI BAWAH INI  🚀
</h2 align="center">
https://t.me/CasperGaming
<h2><hr>

<h2 align="center">
🚀 Autoscript SSH XRAY Websocket Multiport By FastNet 🚀
<h2><hr>

<h2 align="center"> ♦️Supported Linux Distribution♦️</h2>
</h2 align="center">
</p>
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=blue"> <br>
<img src="https://img.shields.io/badge/Service-Multiport (XRAY)-orange"></p>

## ⚠️ PLEASE README ⚠️
 <br>

 SILAHKAN SETTING DOMAIN DI CLOUDFLARE ANDA SEPERTI DIBAWAH (SSL/TLS SETTINGS) <br>
 ![image](https://user-images.githubusercontent.com/82468311/191471897-986ebe25-5330-4997-8a44-5468b422482a.png) <br>

![image](https://user-images.githubusercontent.com/82468311/191472903-b55cd39a-8909-4f7c-b3ad-013cb3c91282.png)

<br>
</b>

## ⏩ AUTOSCRIPT WEBSOCKET MULTIPORT 443 DETAILS ⏪
<br>
[ SSH & XRAY SERVICES ] <br>
<br>
⏩ Open VPN                : 2086 ⏪ <br>
⏩ SSH SSL Websocket       : 443 ⏪<br>
⏩ SSH Websocket           : [ all port ] ⏪<br>
⏩ Stunnel                 : 8443,8880 ⏪<br>
⏩ Vmess WS TLS            : 443 ⏪<br>
⏩ Vless WS TLS            : 443 ⏪<br>
⏩ Trojan WS TLS           : 443 ⏪<br>
⏩ Shadowsocks WS TLS      : 443 ⏪<br>
⏩ Vmess gRPC              : 443 ⏪<br>
⏩ Vless gRPC              : 443 ⏪<br>
⏩ Trojan gRPC             : 443 ⏪<br>
⏩ Shadowsocks gRPC        : 443 ⏪<br>
⏩ Vmess WS none TLS       : 80 ⏪<br>
⏩ Vless WS none TLS       : 80 ⏪<br>
⏩ Trojan WS none TLS      : 80 ⏪<br>
⏩ Shadowsocks WS none TLS : 80 ⏪<br>
<br>
<br>
<br>
