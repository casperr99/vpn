#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Checking VPS"
CEKEXPIRED () {
    today=$(date -d +1day +%Y-%m-%d)
    Exp1=$(curl -sS https://raw.githubusercontent.com/lianpujisatria/permission/main/ipmini | grep $MYIP | awk '{print $3}')
    if [[ $today < $Exp1 ]]; then
    echo -e "\e[32mSTATUS SCRIPT AKTIF...\e[0m"
    else
    echo -e "\e[31mSCRIPT ANDA EXPIRED!\e[0m";

    exit 0
fi
}
IZIN=$(curl -sS https://raw.githubusercontent.com/lianpujisatria/permission/main/ipmini | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
echo -e "\e[32mPermission Accepted...\e[0m"
CEKEXPIRED
else
echo -e "\e[31mPermission Denied!\e[0m";

exit 0
fi
clear
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
###########- COLOR CODE -##############
echo -e "$COLOR1┌─────────────────────────────────────────────────┐${NC}"
echo -e "$COLOR1 ${NC} ${COLBG1}                 ${WH}⇱ UPDATE ⇲                    ${NC} $COLOR1 $NC"
echo -e "$COLOR1 ${NC} ${COLBG1}                ${WH}⇱ DI MULAI ⇲                   ${NC} $COLOR1 $NC"
echo -e "$COLOR1└─────────────────────────────────────────────────┘${NC}"
sleep 1
clear
#hapus menu
rm -rf menu
rm -rf m-vmess
rm -rf m-vless
rm -rf m-trojan
rm -rf m-system
rm -rf m-sshovpn
rm -rf m-ssws
rm -rf running
rm -rf m-update
rm -rf m-backup
rm -rf m-theme
rm -rf m-ip
rm -rf m-bot
rm -rf update
rm -rf ws-dropbear
rm -rf bckpbot
rm -rf tendang
rm -rf bottelegram
rm -rf restore
rm -rf backup
rm -rf cleaner
rm -rf m-allxray


# download menu
cd /usr/bin
rm -rf menu
rm -rf m-vmess
rm -rf m-vless
rm -rf m-trojan
rm -rf m-system
rm -rf m-sshovpn
rm -rf m-ssws
rm -rf running
rm -rf m-backup
rm -rf m-theme
rm -rf m-ip
rm -rf m-bot
rm -rf update
rm -rf ws-dropbear
rm -rf bckpbot
rm -rf tendang
rm -rf bottelegram
rm -rf restore
rm -rf backup
rm -rf cleaner
rm -rf m-allxray


wget -O /usr/bin/menu "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/menu.sh" && chmod +x /usr/bin/menu
wget -O /usr/bin/m-vmess "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-vmess.sh" && chmod +x /usr/bin/m-vmess
wget -O /usr/bin/m-vless "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-vless.sh" && chmod +x /usr/bin/m-vless
wget -O /usr/bin/m-trojan "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-trojan.sh" && chmod +x /usr/bin/m-trojan
wget -O /usr/bin/m-system "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-system.sh" && chmod +x /usr/bin/m-system
wget -O /usr/bin/m-sshovpn "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-sshovpn.sh" && chmod +x /usr/bin/m-sshovpn
wget -O /usr/bin/m-ssws "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-ssws.sh" && chmod +x /usr/bin/m-ssws
wget -O /usr/bin/running "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/running.sh" && chmod +x /usr/bin/running
wget -O /usr/bin/m-update "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-update.sh" && chmod +x /usr/bin/m-update
wget -O /usr/bin/m-backup "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-backup.sh" && chmod +x /usr/bin/m-backup
wget -O /usr/bin/m-theme "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-theme.sh" && chmod +x /usr/bin/m-theme
wget -O /usr/bin/m-ip "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-ip.sh" && chmod +x /usr/bin/m-ip
wget -O /usr/bin/m-bot "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-bot.sh" && chmod +x /usr/bin/m-bot
wget -O /usr/bin/update "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/update.sh" && chmod +x /usr/bin/update
wget -O /usr/bin/ws-dropbear "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/sshws/ws-dropbear" && chmod +x /usr/bin/ws-dropbear
wget -O /usr/bin/bckpbot "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/bckpbot.sh" && chmod +x /usr/bin/bckpbot
wget -O /usr/bin/tendang "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/tendang.sh" && chmod +x /usr/bin/tendang
wget -O /usr/bin/bottelegram "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/bottelegram.sh" && chmod +x /usr/bin/bottelegram
wget -O /usr/bin/backup "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/backup.sh" && chmod +x /usr/bin/backup
wget -O /usr/bin/restore "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/restore.sh" && chmod +x /usr/bin/restore
wget -O /usr/bin/cleaner "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/install/cleaner.sh" && chmod +x /usr/bin/cleaner
wget -O /usr/bin/m-allxray "https://raw.githubusercontent.com/lianpujisatria/FastNet/main/menu/m-allxray.sh" && chmod +x /usr/bin/m-allxray

chmod +x menu
chmod +x m-vmess
chmod +x m-vless
chmod +x m-trojan
chmod +x m-system
chmod +x m-sshovpn
chmod +x m-ssws
chmod +x running
chmod +x m-update
chmod +x m-backup
chmod +x m-theme
chmod +x m-ip
chmod +x m-bot
chmod +x update
chmod +x bckpbot
chmod +x tendang
chmod +x bottelegram
chmod +x backup
chmod +x restore
chmod +x cleaner
chmod +x m-allxray

clear
echo -e "$COLOR1┌─────────────────────────────────────────────────┐${NC}"
echo -e "$COLOR1 ${NC} ${COLBG1}                 ${WH}⇱ UPDATE ⇲                    ${NC} $COLOR1 $NC"
echo -e "$COLOR1 ${NC} ${COLBG1}               ${WH}⇱ SELESAI....⇲                  ${NC} $COLOR1 $NC"
echo -e "$COLOR1└─────────────────────────────────────────────────┘${NC}"
sleep 1
cd
menu
